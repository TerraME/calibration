files = {
	"SAMDE.lua",
	"GoodnessOfFit.lua",
	"MultipleRuns.lua",
	"utils.lua"
}
